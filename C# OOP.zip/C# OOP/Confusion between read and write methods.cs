﻿// Confusion between read and write methods

using System;
namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            string readline;
            Console.WriteLine("ReadLine");
            readline = Console.ReadLine();
            Console.WriteLine(readline);

            Console.WriteLine("Read()");
            int read = Console.Read();
            Console.WriteLine(read);

            Console.WriteLine("ReadKey()");
            Console.ReadKey();

            Console.WriteLine("WriteLine");
            Console.Write("Write1 ");
            Console.Write("Write2");


            
        }
    }
}