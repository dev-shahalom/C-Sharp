﻿// IF   ELSE IF   ELSE
using System;
namespace Program
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            a = 100;
            b = 100;

            if (a < b)
            {
                Console.WriteLine("A is Smaller than B");
            }
            else if (a == b)
            {
                Console.WriteLine("A and B are Equal");
            }
            else
            {
                Console.WriteLine("A is Larger than B");
            }
        }

    }
}