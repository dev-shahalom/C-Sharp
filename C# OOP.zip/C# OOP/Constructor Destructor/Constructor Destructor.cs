﻿// Constructor & Destructor
// https://www.youtube.com/watch?v=RTvJJHajibg&list=PLCqWuVe6WFLLmMTO44hpYKnptJ6765skH&index=18

using System;
namespace Program
{
    class ABC
    {
        public string name; // member variable
        public int age;
        public ABC(string username, int age)        //constructor
        {
            name = username;
            this.age = age;            // this.  dite hobe bcz same name, jeno confusion na lagay tay.  otherwise onno word use kora jabe jmn "userage"
        }

        ~ABC()
        {
            Console.WriteLine("Destructor Executed !");
        }
        static void Main(string[] args)
        {
            string username = "Muhib";
            int age = 20;
            ABC obj = new ABC(username, age);   //created an object 
            Console.WriteLine("Name : " + obj.name);  //passing parameter to object 
            Console.WriteLine("Age : " + obj.age);


        }
    }
}