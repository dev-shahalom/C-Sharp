﻿//Switch Case Program Example
using System;
namespace Program
{
    class Program
    {
        static void Main(string[] args)
        {
            char ch;
            Console.Write("Enter A Character : ");
            ch = Convert.ToChar(Console.ReadLine());

            switch (Char.ToUpper(ch))
            {
                case 'a': Console.WriteLine("A is Vowel"); break;
                case 'e': Console.WriteLine("E is Vowel"); break;
                case 'i': Console.WriteLine("I is Vowel"); break;
                case 'o': Console.WriteLine("O is Vowel"); break;
                case 'u': Console.WriteLine("U is Vowel"); break;
                default: Console.WriteLine("{0} is Consonant", ch); break;
            }
        }

    }
}