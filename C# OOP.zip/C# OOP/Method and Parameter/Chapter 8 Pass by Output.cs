﻿// Chapter 8
// Method
// Call by Output


using System;
namespace OOP
{

    class Method
    {
        public int sum(out int a, out int b)
        {
            a = 100;
            b = 200;
            int sum = a + b;
            return sum;
        }
        static void Main(string[] args)
        {
            Method m = new Method();
            int a, b;


            Console.WriteLine("Ans = {0}", m.sum(out a, out b));
        }
    }
}