﻿// Chapter 8
// Method Call Program 
using System;
namespace Program
{
    class Program
    {
        public int sum(int a, int b)
        {
            return a + b;
        }
        static void Main(String[] args)
        {
            int a = 10;
            int b = 20;
            Program m = new Program();
            Console.WriteLine(m.sum(a, b));
        }
    }
}