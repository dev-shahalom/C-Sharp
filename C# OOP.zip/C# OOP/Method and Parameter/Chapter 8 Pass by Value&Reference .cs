﻿// Chapter 8
// Method
// Call by Value


using System;
namespace OOP
{

    class Method
    {
        public int sum(int a, int b)
        {
            return a + b;
        }
        static void Main(string[] args)
        {
            int a = 100, b = 200;

            Method m = new Method();
            Console.WriteLine("Ans = {0}", m.sum(a, b));
        }
    }
    /*
     * Call By Reference
     
    class Method_ref
    {
        public int sum(ref int a, ref int b)
        {
            return a + b;
        }
        static void Main(string[] args)
        {
            int a = 100, b = 200;

            Method_ref m = new Method_ref();
            Console.WriteLine("Ans = {0}", m.sum(ref a, ref b));
        }
    }
    */
}