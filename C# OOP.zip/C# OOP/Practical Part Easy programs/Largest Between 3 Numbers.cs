﻿//Largest_Between_3_Numbers
using System;
namespace Largest_Between_3_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            a = 10;
            b = 30;
            c = 20;
            if (a > b & a > c)
            {
                Console.WriteLine("Largest A");
            }
            else if (b > a & b > c)
            {
                Console.WriteLine("Largest B");
            }
            else
            {
                Console.WriteLine("Largest C");
            }
        }
    }
}