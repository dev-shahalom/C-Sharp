﻿using System;

namespace ConditionalTriangle
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            a = 3;
            b = 4;
            c = 5;

            double s = (a + b + c) / 2;
            double area = Math.Sqrt(s * (s - a) * (s - b) * (s - c));

            if ((a + b) > c & (b + c) > a & (c + a) > b)
            {
                Console.WriteLine("Triangle of Area : " + area);
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Triangle is not possible");
            }

        }
    }
}