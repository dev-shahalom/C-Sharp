﻿// Factorial
using System;
namespace Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c, n, i;
            a = 0;
            b = 1;
            i = 2;
            n = 10;

            for (i = 0; i < n; i++)
            {
                c = a + b;
                Console.Write(" " + c);
                a = b;
                b = c;
            }

        }
    }
}