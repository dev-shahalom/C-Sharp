﻿// Factorial
using System;
namespace Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            int factorial = 1;

            n = 10; //number

            for (int i = 1; i < n; i++)
            {
                factorial = factorial * i;
            }
            Console.WriteLine(factorial);
        }
    }
}