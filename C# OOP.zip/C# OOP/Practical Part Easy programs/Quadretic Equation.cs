﻿// ax2 + bx + c = 0
using System;
namespace Quadretic_Equation
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c, d;

            Console.Write("Enter A : ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter B : ");
            b = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter C : ");
            c = Convert.ToInt32(Console.ReadLine());

            d = (b * b) - 4 * a * c;

            if (d == 0)
            {
                double x;
                x = -b / (2 * a);
                Console.WriteLine("Roots are Not Equal and are : {0}", x);
            }
            else if (d > 0)
            {
                double x1, x2;
                x1 = -b + Math.Sqrt(d) / (2 * a);
                x2 = -b - Math.Sqrt(d) / (2 * a);
                Console.WriteLine("Roots are Equal and are : {0} {1}", x1, x2);
            }
            else
            {
                Console.WriteLine("Roots are Imaginary");
            }



        }
    }
}