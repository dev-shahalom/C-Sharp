﻿// true_false_with_condition
using System;

namespace true_false_with_condition
{
    class Program
    {
        static void Main(string[] args)
        {

            int num1, num2;
            bool result;

            Console.Write("Enter 1st Number : ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2nd Number : ");
            num2 = Convert.ToInt32(Console.ReadLine());

            if ((num1 % 2 == 0) & (num2 % 2 == 1) | (num1 % 2 == 1) & (num2 % 2 == 0))
            {
                result = false;
            }
            else
            {
                result = true;
            }
            Console.WriteLine(result);
        }
    }
}