﻿// Add 1 to 100
using System;
namespace Add_1_to_100
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 0;
            for (int i = 0; i <= 100; i++)
            {
                num = num + i;
            }

            Console.Write("Addition of 1 to 100 are = " + num);
        }
    }
}