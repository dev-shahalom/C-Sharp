﻿// 
using System;
namespace Program_Name
{
    class Adding2Num
    {
        //////////////////////////////////////////////////
        //// Adding 2 number                            //
        //  static void Main(string[] args)             //
        //  {                                           //
        //      int a = 10;                             //
        //      int b = 20;                             //
        //      int sum = a + b;                        //
        //      Console.WriteLine("Sum is : " + sum);   //
        //  }                                           //
        //////////////////////////////////////////////////
    }
    class Interchange
    {
        // Swapping 2 Number
        static void Main(string[] args)
        {
            int a, b, temp; //init
            a = 10;
            b = 20;

            Console.Write("Before Swapping : ");
            Console.WriteLine("A = {0}  |   B = {1}", a, b);

            // Swap
            temp = a;
            a = b;
            b = temp;

            Console.Write("After Swapping : ");
            Console.WriteLine("A = {0}  |   B = {1}", a, b);
        }
    }



}