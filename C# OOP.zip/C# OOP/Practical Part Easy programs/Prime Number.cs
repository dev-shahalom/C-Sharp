﻿// Prime Number
using System;
namespace Prime_Number
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 11; //number

            if (n % 2 == 0)
            {
                Console.WriteLine("{0} is a Prime Number", n);
            }
            else
            {
                Console.WriteLine("Not a Prime Number");
            }
        }
    }
}