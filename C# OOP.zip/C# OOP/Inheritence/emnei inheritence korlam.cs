﻿//Multiple Inheritence

using System;
namespace Inheritance
{
    class A
    {
        public string name;
        public int roll;
        public int id;
        public void print()
        {
            Console.WriteLine("Name : " + name);
            Console.WriteLine("Roll : " + roll);
            Console.WriteLine("ID : " + id);
        }
    }
    class B : A
    {
        public int xyz = 1092104;
        public void printxyz()
        {
            Console.WriteLine("XYZ = " + xyz);
        }
    }
    class C : B
    {
        public int abc = 100011;
        public void printabc()
        {
            Console.WriteLine("ABC = " + abc);
        }

    }
    class Program : C
    {
        static void Main(string[] args)
        {
            Program obj1 = new Program();
            obj1.name = "Muhib";
            obj1.roll = 577952;
            obj1.id = 1010;
            obj1.printxyz();
            obj1.printabc();
            obj1.print();
            Console.ReadKey();
        }
    }
}