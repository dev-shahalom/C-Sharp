﻿//Multilevel Inheritence
using System;
namespace Inheritance
{
    class A
    {
        public string name;
        public int roll;
        public void printA()
        {
            Console.WriteLine("Name : " + name);
            Console.WriteLine("Roll : " + roll);
        }
    }
    class B : A
    {
        public char group;
        public int id;
        public void printB()
        {
            Console.WriteLine("Group : " + group);
            Console.WriteLine("ID : " + id);
        }
    }
    class C : B
    {
        public int session;
        public float mark;
        public void printC()
        {
            Console.WriteLine("Session : " + session);
            Console.WriteLine("Mark : " + mark);
        }
    }
    class Program : C
    {
        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.name = "Muhib";
            obj.id = 1010;
            obj.roll = 577952;
            obj.group = 'A';
            obj.session = 2021;
            obj.mark = 4.00f;
            obj.printA();
            obj.printB();
            obj.printC();
        }
    }
}