﻿//Single Inheritence
using System;
namespace Inheritance
{
    class A
    {
        public string name;
        public int id;
        public void print()
        {
            Console.WriteLine("Name : " + name);
            Console.WriteLine("ID : " + id);
        }
    }
    class Program : A
    {
        static void Main(string[] args)
        {
            Program obj = new Program();
            obj.name = "Muhib";
            obj.id = 1010;
            obj.print();
        }
    }
}