﻿// Chapter 9
// Encapsulation Program

using System;
namespace Program
{
    class Account
    {
        private int id = 1111;  //this is protected

        public int ID   //this is called properties
        {
            set     //properties > set method
            {
                id = value;
            }
            get     //properties > get method
            {
                return id;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Account a = new Account();  //created an object for Account class
            a.ID = 1710212514;          //set using set method
            Console.WriteLine(a.ID);    //get using get method
        }
    }
}