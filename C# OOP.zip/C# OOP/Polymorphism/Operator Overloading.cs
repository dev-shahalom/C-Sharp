﻿//Operator Overloading
using System;
namespace ProgramName
{
    class Program
    {
        public string name;     //declare global.variable
        public int num;

        public static Program operator +(Program obj1, Program obj2) //special method for overloading 
        {
            Program obj3 = new Program();           //for access global variable
            obj3.name = obj1.name + " " + obj2.name;  //concatenate string 
            obj3.num = obj1.num + obj2.num;         //adding integer

            return obj3;
        }
        static void Main(string[] args)
        {
            Program obj1 = new Program();   //obj1 for 1st part
            obj1.name = "Md. Muhibbur";        //initialize
            obj1.num = 01717109000;

            Program obj2 = new Program();   //obj2 for 2nd part
            obj2.name = "Rahman";              //initialize
            obj2.num = 550;

            Program obj3 = new Program();
            obj3 = obj1 + obj2;             // overloaded "+" operator
            Console.WriteLine(obj3.name);   //print name
            Console.WriteLine(obj3.num);    //print num

        }
    }
}