﻿// Method Overloading
using System;

namespace MethodOverloading
{
    class Program
    {
        public int Add(int x, int y)
        {
            int sum = x + y;
            return sum;
        }

        public int Add(int x, int y, int z)
        {
            int sum = x + y + z;
            return sum;
        }

        static void Main(string[] args)
        {
            Program obj = new Program();    //object with class

            int num1 = obj.Add(10, 20);
            int num2 = obj.Add(10, 20, 30); // set value to a new int

            Console.WriteLine("num1 : " + num1);
            Console.WriteLine("num2 : " + num2);
        }
    }
}